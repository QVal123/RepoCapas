<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <div>
        <h1> Módulo de Categoria <h1>
        <hr>
        <a href="guardarcategoria.php" >Crear Nuevo </a>
        <?php
            require_once '../entidades/Categoria.php';
            require_once '../interfaces/ICategoria.php';
            require_once '../logica/LCategoria.php';
            $log=new LCategoria();
            $categorias=$log->cargar();
        ?>
        <table border='1'>
            <thead>
                <tr>
                    <th>Id</th>
                    <th>Nombre</th>
                    <th>IdFamilia</th>
                    <th>Modificar</th>
                    <th>Borrar</th>
                </tr>
            </thead>
            <tbody>
                <?php
                foreach($categorias as $cat){
                ?>
                <tr>
                    <td><?=$cat->getIdFamilia()?></td>
                    <td><?=$cat->getNombre()?></td>
                    <td><?=$cat->getIdFamilia()?></td>
                    <td><a href="modificarfamilia.php">Modificar</a></td>
                    <td><a href="borrarfamilia.php?idfam=<?=$f[0]?>">Borrar</a></td>
                </tr>
                <?php
                }
                ?>
            </tbody>
    </div>
</body>
</html>
